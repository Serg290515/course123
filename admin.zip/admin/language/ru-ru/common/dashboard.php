<?php
// Heading
$_['heading_title'] = 'Панель состояния';

// Error
$_['error_install'] = 'ВНИМАНИЕ: Установочная папка до сих пор существует! Удалите папку install';