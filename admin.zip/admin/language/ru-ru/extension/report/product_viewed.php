<?php
// Heading
$_['heading_title']    = 'Просмотр товаров';

// Text
$_['text_extension']   = 'Расширения';
$_['text_edit']        = 'Редактирование';
$_['text_success']     = 'Сброс отчета успешно выполнен!';

// Column
$_['column_name']      = 'Название товара';
$_['column_model']     = 'Модель';
$_['column_viewed']    = 'Просмотров';
$_['column_percent']   = 'Процент';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';

// Error
$_['error_permission'] = 'У Вас нет прав для управления модулем!';

